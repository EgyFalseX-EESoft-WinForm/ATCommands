using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Text;
using System.Windows.Forms;
using DevExpress.Skins;
using DevExpress.LookAndFeel;
using DevExpress.UserSkins;
using DevExpress.XtraEditors;
using System.IO.Ports;
using System.Threading;
using System.Data.SqlClient;
using System.Runtime.Serialization.Formatters.Binary;
using Alias = System.Windows.Forms;


namespace ATCommands
{
    public partial class MainFrm : XtraForm
    {
        #region -   Variables   -
        //SMS objclsSMS = new SMS();
        private readonly DevExpress.XtraBars.RibbonGalleryBarItem rgbiSkins = new DevExpress.XtraBars.RibbonGalleryBarItem();
        public DataTable ActionLogTbl = new DataTable("FX2011-10");
        public AutoResetEvent receiveNow;
        enum messageStatus
        {
            �����,
            ����,
            �����
        }
        #endregion
        #region -   Functions   -
        public MainFrm()
        {
            InitializeComponent();
            InitSkinGallery();
            DevExpress.XtraBars.Helpers.SkinHelper.InitSkinGallery(rgbiSkins, true, true);
        }
        void InitSkinGallery()
        {
            DevExpress.XtraBars.Ribbon.RibbonControl ribbonControl = new DevExpress.XtraBars.Ribbon.RibbonControl();
            ribbonControl.Items.Add(rgbiSkins);
            DevExpress.XtraBars.Helpers.SkinHelper.InitSkinGallery(rgbiSkins, true);
        }
        private static UserSettings LoadSettings(string fileName)
        {
            UserSettings us = null;
            BinaryFormatter binFormat = new BinaryFormatter();
            System.IO.Stream fStream = new System.IO.FileStream(fileName, System.IO.FileMode.Open);
            try { us = binFormat.Deserialize(fStream) as UserSettings; }
            finally { fStream.Close(); }
            return us;
        }
        private static void SaveSettings(UserSettings us)
        {
            BinaryFormatter binFormat = new BinaryFormatter();
            using (System.IO.Stream fStream = new System.IO.FileStream(MyCL.StyleSettingsPath, System.IO.FileMode.Create, System.IO.FileAccess.Write, System.IO.FileShare.None))
            {
                binFormat.Serialize(fStream, us);
                fStream.Close();
            }
        }

        private void LoadPorts()
        { 
            CBEPort.Properties.Items.AddRange(SerialPort.GetPortNames());
        }
        private static DataTable LoadSetting()
        {
            return MyCL.LoadDataTable(@"Select ServiceNum From Setting");
        }
        private static DataTable LoadUsers()
        {
            return MyCL.LoadDataTable(@"Select UserID, UserName, PassWord From Users");
        }
        private static DataTable LoadTemplates()
        {
            return MyCL.LoadDataTable(@"Select TemplateId, TemplateTitle, TemplateBody From Templates");
        }
        private static DataTable LoadGroups()
        {
            return MyCL.LoadDataTable(@"Select Groupid, GroupName From Groups"); ;
        }
        private static DataTable LoadContacts()
        {
            return MyCL.LoadDataTable(@"Select ContactID, ContactName, ContactNumber, GroupID From Contacts");
            //Groups.TableName = "Groups";
            //Contacts.TableName = "Contacts";
            //DataSet dataSetGroupContact = new DataSet("dataSetGroupContact");
            //dataSetGroupContact.Tables.AddRange(new System.Data.DataTable[] { Groups, Contacts });
            //dataSetGroupContact.Relations.Add("LvlContacts", Groups.Columns["GroupName"], Contacts.Columns["GroupID"]);
            //gridControlMain.MainView = gridViewGroups;
            //gridControlMain.DataSource = dataSetGroupContact;
            //gridControlMain.DataMember = "Groups";
        }
        private static DataTable LoadMessages()
        {
            //Convert(nvarchar, SendTime, 103) AS 
            return MyCL.LoadDataTable(@"Select messageid, messageBody, number, (Select StatusName From messageStatus Where Statusid = Messages.status) AS status, 
            SendTime From Messages");
        }
        private static DataTable LoadStyle()
        {
            DataTable dtStyles = new DataTable();
            //Columns
            dtStyles.Columns.Add("StykeName");
            //Rows
            dtStyles.Rows.Add("Black");
            dtStyles.Rows.Add("Blue");
            dtStyles.Rows.Add("Caramel");
            dtStyles.Rows.Add("DevExpress Dark Style");
            dtStyles.Rows.Add("DevExpress Style");
            dtStyles.Rows.Add("iMaginary");
            dtStyles.Rows.Add("Lilian");
            dtStyles.Rows.Add("Money Twins");
            dtStyles.Rows.Add("Office 2007 Black");
            dtStyles.Rows.Add("Office 2007 Blue");
            dtStyles.Rows.Add("Office 2007 Green");
            dtStyles.Rows.Add("Office 2007 Pink");
            dtStyles.Rows.Add("Office 2007 Silver");
            dtStyles.Rows.Add("Office 2010 Black");
            dtStyles.Rows.Add("Office 2010 Blue");
            dtStyles.Rows.Add("Office 2010 Silver");
            dtStyles.Rows.Add("Blueprint");
            dtStyles.Rows.Add("Coffee");
            dtStyles.Rows.Add("Dark Side");
            dtStyles.Rows.Add("Darkroom");
            dtStyles.Rows.Add("Foggy");
            dtStyles.Rows.Add("Glass Oceans");
            dtStyles.Rows.Add("High Contrast");
            dtStyles.Rows.Add("Liquid Sky");
            dtStyles.Rows.Add("London Liquid Sky");
            dtStyles.Rows.Add("McSkin");
            dtStyles.Rows.Add("Pumpkin");
            dtStyles.Rows.Add("Seven");
            dtStyles.Rows.Add("Seven Classic");
            dtStyles.Rows.Add("Sharp");
            dtStyles.Rows.Add("Sharp Plus");
            dtStyles.Rows.Add("Springtime");
            dtStyles.Rows.Add("Stardust");
            dtStyles.Rows.Add("Summer 2008");
            dtStyles.Rows.Add("The Asphalt World");
            dtStyles.Rows.Add("Valentine");
            dtStyles.Rows.Add("Whiteprint");
            dtStyles.Rows.Add("Xmas 2008 Blue");
            return dtStyles;
        }
        public string ReadResponse(int timeout)
        {
            string buffer = string.Empty;
            try
            {
                do
                {
                    if (receiveNow.WaitOne(timeout, false))
                    {
                        string t = USBserialPort.ReadExisting();
                        buffer += t;
                    }
                    else
                    {
                        if (buffer.Length > 0)
                            throw new ApplicationException("Response received is incomplete.");
                        else
                            throw new ApplicationException("No data received from phone.");
                    }
                }
                while (!buffer.EndsWith("\r\nOK\r\n") && !buffer.EndsWith("\r\n> ") && !buffer.EndsWith("\r\nERROR\r\n"));
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return buffer;
        }
        public string ExecCommand(string command, int responseTimeout)
        {
            try
            {
                USBserialPort.DiscardOutBuffer();
                USBserialPort.DiscardInBuffer();
                receiveNow.Reset();
                USBserialPort.Write(command + "\r");

                string input = ReadResponse(responseTimeout);
                if ((input.Length == 0) || ((!input.EndsWith("\r\n> ")) && (!input.EndsWith("\r\nOK\r\n"))))
                    throw new ApplicationException("�� ������� ����� ���� �� ������");
                return input;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        private static string GetPDU(string ServiceCenterNumber, string Destination_Address, string User_Data)
        {
            FXPDU.SMS PDUCls = new FXPDU.SMS();
            PDUCls.TP_Data_Coding_Scheme = FXPDU.SMS.ENUM_TP_DCS.UCS2;
            PDUCls.ServiceCenterNumber = ServiceCenterNumber;
            PDUCls.TP_Destination_Address = Destination_Address;
            PDUCls.TP_User_Data = User_Data;
            PDUCls.TP_Status_Report_Request = FXPDU.SMS.ENUM_TP_SRI.No_SMS_Report;
            PDUCls.TP_Validity_Period = FXPDU.SMS.ENUM_TP_VALID_PERIOD.Maximum;
            PDUCls.TP_Message_Reference = 0;
            return PDUCls.GetSMSPDUCode();
        }
        private static string GetPDULength(string PDU)
        {
            int strLen = Convert.ToInt32(PDU.Substring(0, 2));
            strLen *= 2;
            strLen = PDU.Length - strLen - 2;
            strLen /= 2;
            return strLen.ToString();
        }
        private void SaveSentMessageLog(string messageBody, string number, messageStatus Status)
        {
            using (SqlConnection con = new SqlConnection(MyCL.SqlConStr))
            {
                SqlCommand cmd = new SqlCommand("", con);
                try
                {
                    cmd.CommandText = string.Format(@"Insert Into Messages (messageBody, number, status, SendTime) VALUES (N'{0}', N'{1}', N'{2}', GETDATE())", messageBody, number, Status);
                    con.Open();
                    cmd.ExecuteNonQuery();
                }
                catch (SqlException ex)
                {
                    MyCL.ShowMsg(MyCL.CheckExp(ex), true, this);
                }
                con.Close();
            }
        }
        #endregion
        #region - Event Handlers -

        private void MainFrm_Load(object sender, EventArgs e)
        {
            SplashFrm SC = new SplashFrm();
            SC.ShowDialog();
            LoginFrm FrmLogin = new LoginFrm();
            FrmLogin.ShowDialog();

            //Load Groups.
            repositoryItemGridLookUpEditGroupName.DataSource = LoadGroups();
            repositoryItemGridLookUpEditGroupName.DisplayMember = "GroupName";
            repositoryItemGridLookUpEditGroupName.ValueMember = "GroupName";

            ActionLogTbl.Columns.Add("details");
            LoadPorts();// Load PortsName in list.
            USBserialPort.Encoding = Encoding.GetEncoding("iso-8859-1");
            gridControlMain.MainView = gridViewSetting;
            gridControlMain.DataSource = LoadSetting();

            if (System.IO.File.Exists(MyCL.StyleSettingsPath))
                UserLookAndFeel.Default.SetSkinStyle(LoadSettings(MyCL.StyleSettingsPath).SkinName);
        }
        private void navBarItemMessages_LinkClicked(object sender, DevExpress.XtraNavBar.NavBarLinkEventArgs e)
        {
            gridControlMain.MainView = gridViewMessages;
            gridControlMain.DataSource = LoadMessages();
        }
        private void navBarItemGroups_LinkClicked(object sender, DevExpress.XtraNavBar.NavBarLinkEventArgs e)
        {
            gridControlMain.MainView = gridViewGroups;
            gridControlMain.DataSource = LoadGroups();
            
        }
        private void navBarItemContacts_LinkClicked(object sender, DevExpress.XtraNavBar.NavBarLinkEventArgs e)
        {
            gridControlMain.MainView = gridViewContacts;
            gridControlMain.DataSource = LoadContacts();
            
        }
        private void navBarItemUsers_LinkClicked(object sender, DevExpress.XtraNavBar.NavBarLinkEventArgs e)
        {
            gridControlMain.MainView = gridViewUsers;
            gridControlMain.DataSource = LoadUsers();
        }
        private void navBarItemTemplates_LinkClicked(object sender, DevExpress.XtraNavBar.NavBarLinkEventArgs e)
        {
            gridControlMain.MainView = gridViewTemplates;
            gridControlMain.DataSource = LoadTemplates();
        }
        private void navBarItemSetting_LinkClicked(object sender, DevExpress.XtraNavBar.NavBarLinkEventArgs e)
        {
            gridControlMain.MainView = gridViewSetting;
            gridControlMain.DataSource = LoadSetting();
        }
        private void navBarItemStyles_LinkClicked(object sender, DevExpress.XtraNavBar.NavBarLinkEventArgs e)
        {
            gridControlMain.MainView = layoutViewSkinStyle;
            gridControlMain.DataSource = LoadStyle();
        }
        private void BtnConnect_Click(object sender, EventArgs e)
        {
            //System.Windows.Forms.MessageBox.Show(ExecCommand(port, "AT+CSCS=?", 300, "What")); //Port is okay to accept 
            receiveNow = new AutoResetEvent(false);
            try
            {
                USBserialPort.PortName = CBEPort.Text;
                USBserialPort.Open();
                string recievedData = ExecCommand("AT", 300);//No phone connected
                USBserialPort.DtrEnable = true;
                USBserialPort.RtsEnable = true;

                if (USBserialPort != null)
                {
                    PnlConnection.Enabled = false;
                    PnlSend.Enabled = true;
                    BtnDisconnect.Visible = true;
                    TmrSignal.Enabled = true;
                    MyCL.ShowMsg("�� ������� �� ���� ���� : " + CBEPort.Text, false, this);

                }
                else
                    MyCL.ShowMsg("�� ��� ������� �� ���� ����", true, this);//Invalid port settings
            }
            catch (Exception ex)
            {
                
                MessageBox.Show(ex.Message, "��������", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }
        private void BtnDisconnect_Click(object sender, EventArgs e)
        {
            try
            {
                TmrSignal.Enabled = false;
                USBserialPort.Close();
                PnlConnection.Enabled = true;
                PnlSend.Enabled = false;
                BtnDisconnect.Visible = false;
                MyCL.ShowMsg("�� ��� �������", false, this);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "��������", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void USBserialPort_DataReceived(object sender, SerialDataReceivedEventArgs e)
        {
            try
            {
                if (e.EventType == SerialData.Chars)
                {
                    receiveNow.Set();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        private void btnSend_Click(object sender, EventArgs e)
        {
            TmrSignal.Stop(); TmrSignal.Enabled = false;// stop getting the signal and get ready to send sms

            try
            {
                string recievedData = ExecCommand("AT", 300);//No phone connected
                recievedData = ExecCommand("AT+CMGF=0", 300);//Failed to set message format.
                recievedData = ExecCommand("AT+CSMS=0", 300);//Failed to set message format.
                if (recievedData.Contains("ERROR"))
                {
                    MyCL.ShowMsg("�� ��� �������", true, this);
                    return;
                }
                for (int i = 0; i < LBCSendTo.Items.Count; i++)
                {
                    string command = string.Empty;
                    string Logger = string.Empty;
                    string pdu = GetPDU(TxtServiceNum.Text.Trim(), LBCSendTo.Items[i].ToString(), TxtMsg.Text);
                    string pduLength = GetPDULength(pdu);
                    Logger += ExecCommand("AT+CMGS=" + pduLength, 300);//Failed to set message Length.
                    command = String.Format("{0}{1}\r", pdu, char.ConvertFromUtf32(26));
                    Logger += ExecCommand(command, 10000);//"Failed to send message
                    if (recievedData.EndsWith("\r\nOK\r\n"))
                    {
                        SaveSentMessageLog(TxtMsg.Text, LBCSendTo.Items[i].ToString(), messageStatus.�����);
                        MyCL.ShowMsg("�� ������� ��� " + LBCSendTo.Items[i].ToString(), false, this);
                    }
                    else if (recievedData.Contains("ERROR"))
                    {
                        SaveSentMessageLog(TxtMsg.Text, LBCSendTo.Items[i].ToString(), messageStatus.����);
                        MyCL.ShowMsg("�� ��� ������� ��� " + LBCSendTo.Items[i].ToString(), true, this);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            TmrSignal.Enabled = true;// start getting the signal again
        }
        private void BtnDelSendTo_Click(object sender, EventArgs e)
        {
            if (LBCSendTo.SelectedItem != null)
                LBCSendTo.Items.Remove(LBCSendTo.SelectedItem);
        }
        private void repositoryItemButtonEditSettingUse_ButtonClick(object sender, DevExpress.XtraEditors.Controls.ButtonPressedEventArgs e)
        {
            
            switch (gridControlMain.MainView.Name)
            {
                case "gridViewSetting":
                    DataRow rowSetting = gridViewSetting.GetFocusedDataRow();
                    TxtServiceNum.Text = rowSetting["ServiceNum"].ToString();
                    break;

                case "gridViewGroups":
                    DataRow rowGroups = gridViewGroups.GetFocusedDataRow();
                    DataTable dt = MyCL.LoadDataTable(String.Format(@"Select ContactNumber From Contacts Where GroupID = N'{0}'", rowGroups["GroupName"]));
                    foreach (DataRow item in dt.Rows)
                    {
                        if (LBCSendTo.FindString(item["ContactNumber"].ToString()) == -1)
                            LBCSendTo.Items.Add(item["ContactNumber"].ToString());
                    }
                    break;

                case "gridViewContacts":
                    DataRow rowContacts = gridViewContacts.GetFocusedDataRow();
                    if (LBCSendTo.FindString(rowContacts["ContactNumber"].ToString()) == -1)
                        LBCSendTo.Items.Add(rowContacts["ContactNumber"]);
                    break;

                case "gridViewMessages":
                    DataRow rowMessages = gridViewMessages.GetFocusedDataRow();
                    if (LBCSendTo.FindString(rowMessages["number"].ToString()) == -1)
                        LBCSendTo.Items.Add(rowMessages["number"]);
                    TxtMsg.Text += rowMessages["messageBody"];
                    break;

                case "gridViewTemplates":
                    DataRow rowTemplates = gridViewTemplates.GetFocusedDataRow();
                    TxtMsg.Text += rowTemplates["TemplateBody"];
                    break;

                case "layoutViewSkinStyle":
                    DataRow rowSkinStyle = layoutViewSkinStyle.GetFocusedDataRow();
                    UserLookAndFeel.Default.SetSkinStyle(rowSkinStyle["StykeName"].ToString());
                    UserSettings us = new UserSettings { SkinName = UserLookAndFeel.Default.ActiveSkinName };
                    SaveSettings(us);
                    break;

                case "gridViewUsers":
                    break;
                default:
                    break;
            }

        }
        private void repositoryItemButtonEditSettingDel_ButtonClick(object sender, DevExpress.XtraEditors.Controls.ButtonPressedEventArgs e)
        {
            if (MessageBox.Show("�� �� ����Ͽ", "�����...!", MessageBoxButtons.YesNo, MessageBoxIcon.Information) == Alias.DialogResult.No)
                return;
            SqlConnection con = new SqlConnection(MyCL.SqlConStr);
            SqlCommand cmd = new SqlCommand("", con);
            try
            {
                con.Open();
                switch (gridControlMain.MainView.Name)
                {
                    case "gridViewSetting":
                        DataRow rowSetting = gridViewSetting.GetFocusedDataRow();
                        cmd.CommandText = String.Format("Delete From Setting Where ServiceNum = N'{0}'", rowSetting["ServiceNum"]);
                        cmd.ExecuteNonQuery();
                        gridControlMain.DataSource = LoadSetting();
                        break;

                    case "gridViewGroups":
                        DataRow rowGroups = gridViewGroups.GetFocusedDataRow();
                        cmd.CommandText = String.Format("Delete From Groups Where Groupid = {0}", rowGroups["Groupid"]);
                        cmd.ExecuteNonQuery();
                        gridControlMain.DataSource = LoadGroups();
                        break;

                    case "gridViewContacts":
                        DataRow rowContacts = gridViewContacts.GetFocusedDataRow();
                        cmd.CommandText = String.Format("Delete From Contacts Where ContactID = {0}", rowContacts["ContactID"]);
                        cmd.ExecuteNonQuery();
                        gridControlMain.DataSource = LoadContacts();
                        break;

                    case "gridViewMessages":
                        DataRow rowMessages = gridViewMessages.GetFocusedDataRow();
                        cmd.CommandText = String.Format("Delete From Messages Where messageid = {0}", rowMessages["messageid"]);
                        cmd.ExecuteNonQuery();
                        gridControlMain.DataSource = LoadMessages();
                        break;

                    case "gridViewTemplates":
                        DataRow rowTemplates = gridViewTemplates.GetFocusedDataRow();
                        cmd.CommandText = String.Format("Delete From Templates Where TemplateId = {0}", rowTemplates["TemplateId"]);
                        cmd.ExecuteNonQuery();
                        gridControlMain.DataSource = LoadTemplates();
                        break;

                    case "gridViewUsers":
                        DataRow rowUsers = gridViewUsers.GetFocusedDataRow();
                        cmd.CommandText = String.Format("Delete From Users Where UserID = {0}", rowUsers["UserID"]);
                        cmd.ExecuteNonQuery();
                        gridControlMain.DataSource = LoadUsers();
                        break;
                    default:
                        break;
                }
                MyCL.ShowMsg("�� �����", false, this);
            }
            catch (SqlException ex)
            {
                MyCL.ShowMsg(MyCL.CheckExp(ex), true, this);
            }
            con.Close();
        }
        private void repositoryItemButtonEditSave_ButtonClick(object sender, DevExpress.XtraEditors.Controls.ButtonPressedEventArgs e)
        {
            SqlConnection con = new SqlConnection(MyCL.SqlConStr);
            SqlCommand cmd = new SqlCommand("", con);
            try
            {
                con.Open();
                switch (gridControlMain.MainView.Name)
                {
                    case "gridViewSetting":
                        DataRow rowSetting = gridViewSetting.GetFocusedDataRow();
                        cmd.CommandText = String.Format(@"IF Not exists(select * from Setting Where ServiceNum = N'{0}')
                        Insert Into Setting (ServiceNum) VALUES (N'{0}')", rowSetting["ServiceNum"]);
                        cmd.ExecuteNonQuery();
                        gridControlMain.DataSource = LoadSetting();
                        break;

                    case "gridViewGroups":
                        DataRow rowGroups = gridViewGroups.GetFocusedDataRow();
                        cmd.CommandText = String.Format(@"IF Not exists(select * from Groups Where GroupName = N'{0}')
                        Insert Into Groups (GroupName) VALUES (N'{0}')", rowGroups["GroupName"]);
                        cmd.ExecuteNonQuery();
                        gridControlMain.DataSource = LoadGroups();
                        break;

                    case "gridViewContacts":
                        DataRow rowContacts = gridViewContacts.GetFocusedDataRow();
                        if (rowContacts["ContactID"].ToString() == string.Empty)
                        {
                            cmd.CommandText = String.Format(@"Insert Into Contacts (ContactName, ContactNumber, GroupID) VALUES (N'{0}', N'{1}', N'{2}')",
                            rowContacts["ContactName"], rowContacts["ContactNumber"], rowContacts["GroupID"]);
                        }
                        else
                        {
                            cmd.CommandText = String.Format(@"Update Contacts Set ContactName = N'{0}', ContactNumber = N'{1}', GroupID = N'{2}' Where ContactID = {3}",
                            rowContacts["ContactName"], rowContacts["ContactNumber"], rowContacts["GroupID"], rowContacts["ContactID"]);
                        }
                        cmd.ExecuteNonQuery();
                        gridControlMain.DataSource = LoadContacts();
                        break;

                    case "gridViewMessages":
                        //DataRow rowMessages = gridViewMessages.GetFocusedDataRow();
                        //if (rowMessages["messageid"].ToString() == string.Empty)
                        //{
                        //    cmd.CommandText = String.Format(@"Insert Into Messages (messageBody, number, status, SendTime) VALUES (N'{0}', N'{1}', {2}, GETDATE())",
                        //    rowMessages["messageBody"], rowMessages["number"], rowMessages["status"]);
                        //}
                        //else
                        //{
                        //    cmd.CommandText = String.Format(@"Update Messages Set messageBody = N'{0}', number = N'{1}', status = {2} Where messageid = {3}",
                        //    rowMessages["messageBody"], rowMessages["number"], rowMessages["status"], rowMessages["messageid"]);
                        //}
                        //cmd.ExecuteNonQuery();
                        //gridControlMain.DataSource = LoadMessages();
                        break;

                    case "gridViewTemplates":
                        DataRow rowTemplates = gridViewTemplates.GetFocusedDataRow();
                        if (rowTemplates["TemplateId"].ToString() == string.Empty)
                        {
                            cmd.CommandText = String.Format(@"Insert Into Templates (TemplateBody) VALUES (N'{0}')", rowTemplates["TemplateBody"]);
                        }
                        else
                        {
                            cmd.CommandText = String.Format(@"Update Templates Set TemplateBody = N'{0}' Where TemplateId = {1}",
                            rowTemplates["TemplateBody"], rowTemplates["TemplateId"]);
                        }
                        cmd.ExecuteNonQuery();
                        gridControlMain.DataSource = LoadTemplates();
                        break;

                    case "gridViewUsers":
                        DataRow rowUsers = gridViewUsers.GetFocusedDataRow();
                        if (rowUsers["UserID"].ToString() == string.Empty)
                        {
                            cmd.CommandText = String.Format(@"Insert Into Users (PassWord, UserName) VALUES (N'{0}', N'{1}')",
                            rowUsers["PassWord"], rowUsers["UserName"]);
                        }
                        else
                        {
                            cmd.CommandText = String.Format(@"Update Users Set PassWord = N'{0}', UserName = N'{1}' Where UserID = {2}",
                            rowUsers["PassWord"], rowUsers["UserName"], rowUsers["UserID"]);
                        }
                        cmd.ExecuteNonQuery();
                        gridControlMain.DataSource = LoadUsers();
                        
                        break;
                    default:
                        break;
                }
                MyCL.ShowMsg("�� �����", false, this);
            }
            catch (SqlException ex)
            {
                MyCL.ShowMsg(MyCL.CheckExp(ex), true, this);
            }
            
        }
        #endregion

        private void TmrSignal_Tick(object sender, EventArgs e)
        {
            try
            {
                string signal = ExecCommand("AT+CSQ", 5000);
                if (signal.Contains("+CSQ:"))
                    PBSignal.EditValue = MyCL.ConvertStringToInt(signal.Substring(signal.IndexOf(Convert.ToChar(":")) + 1));
                else
                    PBSignal.EditValue = "0";
            }
            catch (Exception ex)
            {
                PBSignal.EditValue = "0";
                TmrSignal.Enabled = false;
            }
        }
        private void LblMsg_DoubleClick(object sender, EventArgs e)
        {

        }
        private void TxtMsg_EditValueChanged(object sender, EventArgs e)
        {
            //System.Math.Round(,MidpointRounding.AwayFromZero);
            LblMsgCounter.Text = (TxtMsg.Text.Length / 70).ToString();
            if ((TxtMsg.Text.Length % 70) > 0)
                LblMsgCounter.Text = (Convert.ToInt32(LblMsgCounter.Text) + 1).ToString();
            LblCharCounter.Text = (TxtMsg.Text.Length - (Convert.ToInt32(LblMsgCounter.Text) * 70)).ToString();

            LblCharCounter.Text = "��� ������: " + LblCharCounter.Text;
            LblMsgCounter.Text = "��� �������: " + LblMsgCounter.Text;
        }
        
    }
}