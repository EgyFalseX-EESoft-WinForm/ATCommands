namespace ATCommands
{
    partial class MainFrm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            DevExpress.XtraGrid.GridLevelNode gridLevelNode1 = new DevExpress.XtraGrid.GridLevelNode();
            DevExpress.XtraGrid.GridLevelNode gridLevelNode2 = new DevExpress.XtraGrid.GridLevelNode();
            DevExpress.XtraGrid.GridLevelNode gridLevelNode3 = new DevExpress.XtraGrid.GridLevelNode();
            DevExpress.XtraGrid.GridLevelNode gridLevelNode4 = new DevExpress.XtraGrid.GridLevelNode();
            DevExpress.XtraGrid.GridLevelNode gridLevelNode5 = new DevExpress.XtraGrid.GridLevelNode();
            DevExpress.XtraGrid.GridLevelNode gridLevelNode6 = new DevExpress.XtraGrid.GridLevelNode();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainFrm));
            this.gridViewGroups = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.GCGroupsGroupName = new DevExpress.XtraGrid.Columns.GridColumn();
            this.GCGroupUse = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemButtonEditSettingUse = new DevExpress.XtraEditors.Repository.RepositoryItemButtonEdit();
            this.GCGroupsSave = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemButtonEditSave = new DevExpress.XtraEditors.Repository.RepositoryItemButtonEdit();
            this.GCGroupDel = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemButtonEditSettingDel = new DevExpress.XtraEditors.Repository.RepositoryItemButtonEdit();
            this.gridControlMain = new DevExpress.XtraGrid.GridControl();
            this.gridViewMessages = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.GCMessagesnumber = new DevExpress.XtraGrid.Columns.GridColumn();
            this.GCMessagesmessageBody = new DevExpress.XtraGrid.Columns.GridColumn();
            this.GCMessagesstatus = new DevExpress.XtraGrid.Columns.GridColumn();
            this.GCMessagesSendTime = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemDateEditDate = new DevExpress.XtraEditors.Repository.RepositoryItemDateEdit();
            this.GCMessagesUse = new DevExpress.XtraGrid.Columns.GridColumn();
            this.GCMessageSave = new DevExpress.XtraGrid.Columns.GridColumn();
            this.GCMessagesDel = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridViewTemplates = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.GCTemplateTemplateBody = new DevExpress.XtraGrid.Columns.GridColumn();
            this.GCTemplateSave = new DevExpress.XtraGrid.Columns.GridColumn();
            this.GCTemplateUse = new DevExpress.XtraGrid.Columns.GridColumn();
            this.GCTemplateDel = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridViewUsers = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.GCUsersUserName = new DevExpress.XtraGrid.Columns.GridColumn();
            this.GCUsersPassWord = new DevExpress.XtraGrid.Columns.GridColumn();
            this.GCUsersSave = new DevExpress.XtraGrid.Columns.GridColumn();
            this.GCUsersDel = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridViewContacts = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.GCContactsContactName = new DevExpress.XtraGrid.Columns.GridColumn();
            this.GCContactsContactNumber = new DevExpress.XtraGrid.Columns.GridColumn();
            this.GCContactsGroupID = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemGridLookUpEditGroupName = new DevExpress.XtraEditors.Repository.RepositoryItemGridLookUpEdit();
            this.repositoryItemGridLookUpEdit1View = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.GCGroupName = new DevExpress.XtraGrid.Columns.GridColumn();
            this.GCContactsUse = new DevExpress.XtraGrid.Columns.GridColumn();
            this.GCContactSave = new DevExpress.XtraGrid.Columns.GridColumn();
            this.GCContactsDel = new DevExpress.XtraGrid.Columns.GridColumn();
            this.layoutViewSkinStyle = new DevExpress.XtraGrid.Views.Layout.LayoutView();
            this.layoutViewColumnSkinStyle = new DevExpress.XtraGrid.Columns.LayoutViewColumn();
            this.layoutViewField_layoutViewColumnSkinStyle = new DevExpress.XtraGrid.Views.Layout.LayoutViewField();
            this.layoutViewColumnUse = new DevExpress.XtraGrid.Columns.LayoutViewColumn();
            this.layoutViewField_layoutViewColumnUse = new DevExpress.XtraGrid.Views.Layout.LayoutViewField();
            this.layoutViewCard1 = new DevExpress.XtraGrid.Views.Layout.LayoutViewCard();
            this.gridViewSetting = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.GCServiceNum = new DevExpress.XtraGrid.Columns.GridColumn();
            this.GCSettingSave = new DevExpress.XtraGrid.Columns.GridColumn();
            this.GCSettingUse = new DevExpress.XtraGrid.Columns.GridColumn();
            this.GCSettingDel = new DevExpress.XtraGrid.Columns.GridColumn();
            this.splitContainerControl = new DevExpress.XtraEditors.SplitContainerControl();
            this.navBarControl = new DevExpress.XtraNavBar.NavBarControl();
            this.msmGroup = new DevExpress.XtraNavBar.NavBarGroup();
            this.navBarItemContacts = new DevExpress.XtraNavBar.NavBarItem();
            this.navBarItemGroups = new DevExpress.XtraNavBar.NavBarItem();
            this.navBarItemMessages = new DevExpress.XtraNavBar.NavBarItem();
            this.AdminGroup = new DevExpress.XtraNavBar.NavBarGroup();
            this.navBarItemUsers = new DevExpress.XtraNavBar.NavBarItem();
            this.navBarItemTemplates = new DevExpress.XtraNavBar.NavBarItem();
            this.navBarItemSetting = new DevExpress.XtraNavBar.NavBarItem();
            this.navBarItemStyles = new DevExpress.XtraNavBar.NavBarItem();
            this.navbarImageListLarge = new System.Windows.Forms.ImageList(this.components);
            this.navbarImageList = new System.Windows.Forms.ImageList(this.components);
            this.groupControl1 = new DevExpress.XtraEditors.GroupControl();
            this.LblMsg = new DevExpress.XtraEditors.LabelControl();
            this.BtnDisconnect = new DevExpress.XtraEditors.SimpleButton();
            this.PnlConnection = new DevExpress.XtraEditors.PanelControl();
            this.TxtServiceNum = new DevExpress.XtraEditors.TextEdit();
            this.BtnConnect = new DevExpress.XtraEditors.SimpleButton();
            this.labelControl2 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl1 = new DevExpress.XtraEditors.LabelControl();
            this.CBEPort = new DevExpress.XtraEditors.ComboBoxEdit();
            this.PBSignal = new DevExpress.XtraEditors.ProgressBarControl();
            this.PnlSend = new DevExpress.XtraEditors.PanelControl();
            this.LblCharCounter = new System.Windows.Forms.Label();
            this.btnSend = new DevExpress.XtraEditors.SimpleButton();
            this.BtnDelSendTo = new DevExpress.XtraEditors.SimpleButton();
            this.LBCSendTo = new DevExpress.XtraEditors.ListBoxControl();
            this.TxtMsg = new DevExpress.XtraEditors.MemoEdit();
            this.USBserialPort = new System.IO.Ports.SerialPort(this.components);
            this.TmrSignal = new System.Windows.Forms.Timer(this.components);
            this.LblMsgCounter = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.gridViewGroups)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemButtonEditSettingUse)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemButtonEditSave)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemButtonEditSettingDel)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridControlMain)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridViewMessages)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemDateEditDate)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemDateEditDate.VistaTimeProperties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridViewTemplates)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridViewUsers)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridViewContacts)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemGridLookUpEditGroupName)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemGridLookUpEdit1View)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutViewSkinStyle)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutViewField_layoutViewColumnSkinStyle)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutViewField_layoutViewColumnUse)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutViewCard1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridViewSetting)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainerControl)).BeginInit();
            this.splitContainerControl.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.navBarControl)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.groupControl1)).BeginInit();
            this.groupControl1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PnlConnection)).BeginInit();
            this.PnlConnection.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.TxtServiceNum.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.CBEPort.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBSignal.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PnlSend)).BeginInit();
            this.PnlSend.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.LBCSendTo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtMsg.Properties)).BeginInit();
            this.SuspendLayout();
            // 
            // gridViewGroups
            // 
            this.gridViewGroups.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.Simple;
            this.gridViewGroups.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.GCGroupsGroupName,
            this.GCGroupUse,
            this.GCGroupsSave,
            this.GCGroupDel});
            this.gridViewGroups.GridControl = this.gridControlMain;
            this.gridViewGroups.Name = "gridViewGroups";
            this.gridViewGroups.OptionsView.ColumnAutoWidth = false;
            // 
            // GCGroupsGroupName
            // 
            this.GCGroupsGroupName.AppearanceCell.Options.UseTextOptions = true;
            this.GCGroupsGroupName.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.GCGroupsGroupName.AppearanceHeader.Options.UseTextOptions = true;
            this.GCGroupsGroupName.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.GCGroupsGroupName.Caption = "��� ������";
            this.GCGroupsGroupName.FieldName = "GroupName";
            this.GCGroupsGroupName.Name = "GCGroupsGroupName";
            this.GCGroupsGroupName.Visible = true;
            this.GCGroupsGroupName.VisibleIndex = 0;
            this.GCGroupsGroupName.Width = 406;
            // 
            // GCGroupUse
            // 
            this.GCGroupUse.AppearanceCell.Options.UseTextOptions = true;
            this.GCGroupUse.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.GCGroupUse.AppearanceHeader.Options.UseTextOptions = true;
            this.GCGroupUse.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.GCGroupUse.Caption = "�������";
            this.GCGroupUse.ColumnEdit = this.repositoryItemButtonEditSettingUse;
            this.GCGroupUse.Name = "GCGroupUse";
            this.GCGroupUse.Visible = true;
            this.GCGroupUse.VisibleIndex = 1;
            this.GCGroupUse.Width = 126;
            // 
            // repositoryItemButtonEditSettingUse
            // 
            this.repositoryItemButtonEditSettingUse.AutoHeight = false;
            this.repositoryItemButtonEditSettingUse.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Plus)});
            this.repositoryItemButtonEditSettingUse.Name = "repositoryItemButtonEditSettingUse";
            this.repositoryItemButtonEditSettingUse.TextEditStyle = DevExpress.XtraEditors.Controls.TextEditStyles.HideTextEditor;
            this.repositoryItemButtonEditSettingUse.ButtonClick += new DevExpress.XtraEditors.Controls.ButtonPressedEventHandler(this.repositoryItemButtonEditSettingUse_ButtonClick);
            // 
            // GCGroupsSave
            // 
            this.GCGroupsSave.AppearanceCell.Options.UseTextOptions = true;
            this.GCGroupsSave.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.GCGroupsSave.AppearanceHeader.Options.UseTextOptions = true;
            this.GCGroupsSave.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.GCGroupsSave.Caption = "���";
            this.GCGroupsSave.ColumnEdit = this.repositoryItemButtonEditSave;
            this.GCGroupsSave.Name = "GCGroupsSave";
            this.GCGroupsSave.Visible = true;
            this.GCGroupsSave.VisibleIndex = 2;
            // 
            // repositoryItemButtonEditSave
            // 
            this.repositoryItemButtonEditSave.AutoHeight = false;
            this.repositoryItemButtonEditSave.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.OK)});
            this.repositoryItemButtonEditSave.Name = "repositoryItemButtonEditSave";
            this.repositoryItemButtonEditSave.TextEditStyle = DevExpress.XtraEditors.Controls.TextEditStyles.HideTextEditor;
            this.repositoryItemButtonEditSave.ButtonClick += new DevExpress.XtraEditors.Controls.ButtonPressedEventHandler(this.repositoryItemButtonEditSave_ButtonClick);
            // 
            // GCGroupDel
            // 
            this.GCGroupDel.AppearanceCell.Options.UseTextOptions = true;
            this.GCGroupDel.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.GCGroupDel.AppearanceHeader.Options.UseTextOptions = true;
            this.GCGroupDel.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.GCGroupDel.Caption = "���";
            this.GCGroupDel.ColumnEdit = this.repositoryItemButtonEditSettingDel;
            this.GCGroupDel.Name = "GCGroupDel";
            this.GCGroupDel.Visible = true;
            this.GCGroupDel.VisibleIndex = 3;
            this.GCGroupDel.Width = 98;
            // 
            // repositoryItemButtonEditSettingDel
            // 
            this.repositoryItemButtonEditSettingDel.AutoHeight = false;
            this.repositoryItemButtonEditSettingDel.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Delete)});
            this.repositoryItemButtonEditSettingDel.Name = "repositoryItemButtonEditSettingDel";
            this.repositoryItemButtonEditSettingDel.TextEditStyle = DevExpress.XtraEditors.Controls.TextEditStyles.HideTextEditor;
            this.repositoryItemButtonEditSettingDel.ButtonClick += new DevExpress.XtraEditors.Controls.ButtonPressedEventHandler(this.repositoryItemButtonEditSettingDel_ButtonClick);
            // 
            // gridControlMain
            // 
            this.gridControlMain.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.gridControlMain.EmbeddedNavigator.Buttons.CancelEdit.Visible = false;
            this.gridControlMain.EmbeddedNavigator.Buttons.Edit.Visible = false;
            this.gridControlMain.EmbeddedNavigator.Buttons.EndEdit.Visible = false;
            this.gridControlMain.EmbeddedNavigator.Buttons.Remove.Visible = false;
            gridLevelNode1.LevelTemplate = this.gridViewGroups;
            gridLevelNode1.RelationName = "Level1";
            gridLevelNode2.LevelTemplate = this.gridViewMessages;
            gridLevelNode2.RelationName = "Level2";
            gridLevelNode3.LevelTemplate = this.gridViewTemplates;
            gridLevelNode3.RelationName = "Level3";
            gridLevelNode4.LevelTemplate = this.gridViewUsers;
            gridLevelNode4.RelationName = "Level5";
            gridLevelNode5.LevelTemplate = this.gridViewContacts;
            gridLevelNode5.RelationName = "Level4";
            gridLevelNode6.LevelTemplate = this.layoutViewSkinStyle;
            gridLevelNode6.RelationName = "Level6";
            this.gridControlMain.LevelTree.Nodes.AddRange(new DevExpress.XtraGrid.GridLevelNode[] {
            gridLevelNode1,
            gridLevelNode2,
            gridLevelNode3,
            gridLevelNode4,
            gridLevelNode5,
            gridLevelNode6});
            this.gridControlMain.Location = new System.Drawing.Point(0, 204);
            this.gridControlMain.MainView = this.gridViewSetting;
            this.gridControlMain.Name = "gridControlMain";
            this.gridControlMain.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.repositoryItemButtonEditSettingUse,
            this.repositoryItemButtonEditSettingDel,
            this.repositoryItemDateEditDate,
            this.repositoryItemButtonEditSave,
            this.repositoryItemGridLookUpEditGroupName});
            this.gridControlMain.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.gridControlMain.Size = new System.Drawing.Size(727, 334);
            this.gridControlMain.TabIndex = 0;
            this.gridControlMain.UseEmbeddedNavigator = true;
            this.gridControlMain.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridViewMessages,
            this.gridViewTemplates,
            this.gridViewUsers,
            this.gridViewContacts,
            this.layoutViewSkinStyle,
            this.gridViewSetting,
            this.gridViewGroups});
            // 
            // gridViewMessages
            // 
            this.gridViewMessages.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.Simple;
            this.gridViewMessages.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.GCMessagesnumber,
            this.GCMessagesmessageBody,
            this.GCMessagesstatus,
            this.GCMessagesSendTime,
            this.GCMessagesUse,
            this.GCMessageSave,
            this.GCMessagesDel});
            this.gridViewMessages.GridControl = this.gridControlMain;
            this.gridViewMessages.Name = "gridViewMessages";
            this.gridViewMessages.OptionsView.ColumnAutoWidth = false;
            // 
            // GCMessagesnumber
            // 
            this.GCMessagesnumber.AppearanceCell.Options.UseTextOptions = true;
            this.GCMessagesnumber.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.GCMessagesnumber.AppearanceHeader.Options.UseTextOptions = true;
            this.GCMessagesnumber.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.GCMessagesnumber.Caption = "������ ����";
            this.GCMessagesnumber.FieldName = "number";
            this.GCMessagesnumber.Name = "GCMessagesnumber";
            this.GCMessagesnumber.Visible = true;
            this.GCMessagesnumber.VisibleIndex = 0;
            this.GCMessagesnumber.Width = 107;
            // 
            // GCMessagesmessageBody
            // 
            this.GCMessagesmessageBody.AppearanceCell.Options.UseTextOptions = true;
            this.GCMessagesmessageBody.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.GCMessagesmessageBody.AppearanceHeader.Options.UseTextOptions = true;
            this.GCMessagesmessageBody.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.GCMessagesmessageBody.Caption = "����� �������";
            this.GCMessagesmessageBody.FieldName = "messageBody";
            this.GCMessagesmessageBody.Name = "GCMessagesmessageBody";
            this.GCMessagesmessageBody.Visible = true;
            this.GCMessagesmessageBody.VisibleIndex = 1;
            this.GCMessagesmessageBody.Width = 299;
            // 
            // GCMessagesstatus
            // 
            this.GCMessagesstatus.AppearanceCell.Options.UseTextOptions = true;
            this.GCMessagesstatus.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.GCMessagesstatus.AppearanceHeader.Options.UseTextOptions = true;
            this.GCMessagesstatus.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.GCMessagesstatus.Caption = "������";
            this.GCMessagesstatus.FieldName = "status";
            this.GCMessagesstatus.Name = "GCMessagesstatus";
            this.GCMessagesstatus.Visible = true;
            this.GCMessagesstatus.VisibleIndex = 2;
            this.GCMessagesstatus.Width = 99;
            // 
            // GCMessagesSendTime
            // 
            this.GCMessagesSendTime.AppearanceCell.Options.UseTextOptions = true;
            this.GCMessagesSendTime.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.GCMessagesSendTime.AppearanceHeader.Options.UseTextOptions = true;
            this.GCMessagesSendTime.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.GCMessagesSendTime.Caption = "�������";
            this.GCMessagesSendTime.ColumnEdit = this.repositoryItemDateEditDate;
            this.GCMessagesSendTime.FieldName = "SendTime";
            this.GCMessagesSendTime.Name = "GCMessagesSendTime";
            this.GCMessagesSendTime.Visible = true;
            this.GCMessagesSendTime.VisibleIndex = 3;
            this.GCMessagesSendTime.Width = 90;
            // 
            // repositoryItemDateEditDate
            // 
            this.repositoryItemDateEditDate.AutoHeight = false;
            this.repositoryItemDateEditDate.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemDateEditDate.DisplayFormat.FormatString = "dd/MM/yyyy";
            this.repositoryItemDateEditDate.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.repositoryItemDateEditDate.EditFormat.FormatString = "dd/MM/yyyy";
            this.repositoryItemDateEditDate.EditFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.repositoryItemDateEditDate.Mask.EditMask = "dd/MM/yyyy";
            this.repositoryItemDateEditDate.Name = "repositoryItemDateEditDate";
            this.repositoryItemDateEditDate.VistaTimeProperties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton()});
            // 
            // GCMessagesUse
            // 
            this.GCMessagesUse.AppearanceCell.Options.UseTextOptions = true;
            this.GCMessagesUse.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.GCMessagesUse.AppearanceHeader.Options.UseTextOptions = true;
            this.GCMessagesUse.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.GCMessagesUse.Caption = "�������";
            this.GCMessagesUse.ColumnEdit = this.repositoryItemButtonEditSettingUse;
            this.GCMessagesUse.Name = "GCMessagesUse";
            this.GCMessagesUse.Visible = true;
            this.GCMessagesUse.VisibleIndex = 4;
            this.GCMessagesUse.Width = 106;
            // 
            // GCMessageSave
            // 
            this.GCMessageSave.AppearanceCell.Options.UseTextOptions = true;
            this.GCMessageSave.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.GCMessageSave.AppearanceHeader.Options.UseTextOptions = true;
            this.GCMessageSave.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.GCMessageSave.Caption = "���";
            this.GCMessageSave.ColumnEdit = this.repositoryItemButtonEditSave;
            this.GCMessageSave.Name = "GCMessageSave";
            this.GCMessageSave.Visible = true;
            this.GCMessageSave.VisibleIndex = 5;
            // 
            // GCMessagesDel
            // 
            this.GCMessagesDel.AppearanceCell.Options.UseTextOptions = true;
            this.GCMessagesDel.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.GCMessagesDel.AppearanceHeader.Options.UseTextOptions = true;
            this.GCMessagesDel.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.GCMessagesDel.Caption = "���";
            this.GCMessagesDel.ColumnEdit = this.repositoryItemButtonEditSettingDel;
            this.GCMessagesDel.Name = "GCMessagesDel";
            this.GCMessagesDel.Visible = true;
            this.GCMessagesDel.VisibleIndex = 6;
            // 
            // gridViewTemplates
            // 
            this.gridViewTemplates.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.GCTemplateTemplateBody,
            this.GCTemplateSave,
            this.GCTemplateUse,
            this.GCTemplateDel});
            this.gridViewTemplates.GridControl = this.gridControlMain;
            this.gridViewTemplates.Name = "gridViewTemplates";
            this.gridViewTemplates.OptionsView.ColumnAutoWidth = false;
            // 
            // GCTemplateTemplateBody
            // 
            this.GCTemplateTemplateBody.AppearanceCell.Options.UseTextOptions = true;
            this.GCTemplateTemplateBody.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.GCTemplateTemplateBody.AppearanceHeader.Options.UseTextOptions = true;
            this.GCTemplateTemplateBody.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.GCTemplateTemplateBody.Caption = "�� �������";
            this.GCTemplateTemplateBody.FieldName = "TemplateBody";
            this.GCTemplateTemplateBody.Name = "GCTemplateTemplateBody";
            this.GCTemplateTemplateBody.Visible = true;
            this.GCTemplateTemplateBody.VisibleIndex = 0;
            this.GCTemplateTemplateBody.Width = 389;
            // 
            // GCTemplateSave
            // 
            this.GCTemplateSave.AppearanceCell.Options.UseTextOptions = true;
            this.GCTemplateSave.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.GCTemplateSave.AppearanceHeader.Options.UseTextOptions = true;
            this.GCTemplateSave.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.GCTemplateSave.Caption = "���";
            this.GCTemplateSave.ColumnEdit = this.repositoryItemButtonEditSave;
            this.GCTemplateSave.Name = "GCTemplateSave";
            this.GCTemplateSave.Visible = true;
            this.GCTemplateSave.VisibleIndex = 2;
            this.GCTemplateSave.Width = 110;
            // 
            // GCTemplateUse
            // 
            this.GCTemplateUse.AppearanceCell.Options.UseTextOptions = true;
            this.GCTemplateUse.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.GCTemplateUse.AppearanceHeader.Options.UseTextOptions = true;
            this.GCTemplateUse.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.GCTemplateUse.Caption = "�������";
            this.GCTemplateUse.ColumnEdit = this.repositoryItemButtonEditSettingUse;
            this.GCTemplateUse.Name = "GCTemplateUse";
            this.GCTemplateUse.Visible = true;
            this.GCTemplateUse.VisibleIndex = 1;
            this.GCTemplateUse.Width = 88;
            // 
            // GCTemplateDel
            // 
            this.GCTemplateDel.AppearanceCell.Options.UseTextOptions = true;
            this.GCTemplateDel.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.GCTemplateDel.AppearanceHeader.Options.UseTextOptions = true;
            this.GCTemplateDel.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.GCTemplateDel.Caption = "���";
            this.GCTemplateDel.ColumnEdit = this.repositoryItemButtonEditSettingDel;
            this.GCTemplateDel.Name = "GCTemplateDel";
            this.GCTemplateDel.Visible = true;
            this.GCTemplateDel.VisibleIndex = 3;
            this.GCTemplateDel.Width = 82;
            // 
            // gridViewUsers
            // 
            this.gridViewUsers.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.GCUsersUserName,
            this.GCUsersPassWord,
            this.GCUsersSave,
            this.GCUsersDel});
            this.gridViewUsers.GridControl = this.gridControlMain;
            this.gridViewUsers.Name = "gridViewUsers";
            this.gridViewUsers.OptionsView.ColumnAutoWidth = false;
            // 
            // GCUsersUserName
            // 
            this.GCUsersUserName.AppearanceCell.Options.UseTextOptions = true;
            this.GCUsersUserName.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.GCUsersUserName.AppearanceHeader.Options.UseTextOptions = true;
            this.GCUsersUserName.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.GCUsersUserName.Caption = "��� ��������";
            this.GCUsersUserName.FieldName = "UserName";
            this.GCUsersUserName.Name = "GCUsersUserName";
            this.GCUsersUserName.Visible = true;
            this.GCUsersUserName.VisibleIndex = 0;
            this.GCUsersUserName.Width = 271;
            // 
            // GCUsersPassWord
            // 
            this.GCUsersPassWord.AppearanceCell.Options.UseTextOptions = true;
            this.GCUsersPassWord.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.GCUsersPassWord.AppearanceHeader.Options.UseTextOptions = true;
            this.GCUsersPassWord.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.GCUsersPassWord.Caption = "���� ������";
            this.GCUsersPassWord.FieldName = "PassWord";
            this.GCUsersPassWord.Name = "GCUsersPassWord";
            this.GCUsersPassWord.Visible = true;
            this.GCUsersPassWord.VisibleIndex = 1;
            this.GCUsersPassWord.Width = 188;
            // 
            // GCUsersSave
            // 
            this.GCUsersSave.AppearanceCell.Options.UseTextOptions = true;
            this.GCUsersSave.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.GCUsersSave.AppearanceHeader.Options.UseTextOptions = true;
            this.GCUsersSave.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.GCUsersSave.Caption = "���";
            this.GCUsersSave.ColumnEdit = this.repositoryItemButtonEditSave;
            this.GCUsersSave.Name = "GCUsersSave";
            this.GCUsersSave.Visible = true;
            this.GCUsersSave.VisibleIndex = 2;
            this.GCUsersSave.Width = 105;
            // 
            // GCUsersDel
            // 
            this.GCUsersDel.AppearanceCell.Options.UseTextOptions = true;
            this.GCUsersDel.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.GCUsersDel.AppearanceHeader.Options.UseTextOptions = true;
            this.GCUsersDel.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.GCUsersDel.Caption = "���";
            this.GCUsersDel.ColumnEdit = this.repositoryItemButtonEditSettingDel;
            this.GCUsersDel.Name = "GCUsersDel";
            this.GCUsersDel.Visible = true;
            this.GCUsersDel.VisibleIndex = 3;
            this.GCUsersDel.Width = 90;
            // 
            // gridViewContacts
            // 
            this.gridViewContacts.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.GCContactsContactName,
            this.GCContactsContactNumber,
            this.GCContactsGroupID,
            this.GCContactsUse,
            this.GCContactSave,
            this.GCContactsDel});
            this.gridViewContacts.GridControl = this.gridControlMain;
            this.gridViewContacts.Name = "gridViewContacts";
            this.gridViewContacts.OptionsView.ColumnAutoWidth = false;
            // 
            // GCContactsContactName
            // 
            this.GCContactsContactName.AppearanceCell.Options.UseTextOptions = true;
            this.GCContactsContactName.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.GCContactsContactName.AppearanceHeader.Options.UseTextOptions = true;
            this.GCContactsContactName.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.GCContactsContactName.Caption = "�����";
            this.GCContactsContactName.FieldName = "ContactName";
            this.GCContactsContactName.Name = "GCContactsContactName";
            this.GCContactsContactName.Visible = true;
            this.GCContactsContactName.VisibleIndex = 0;
            this.GCContactsContactName.Width = 259;
            // 
            // GCContactsContactNumber
            // 
            this.GCContactsContactNumber.AppearanceCell.Options.UseTextOptions = true;
            this.GCContactsContactNumber.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.GCContactsContactNumber.AppearanceHeader.Options.UseTextOptions = true;
            this.GCContactsContactNumber.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.GCContactsContactNumber.Caption = "��� �������";
            this.GCContactsContactNumber.FieldName = "ContactNumber";
            this.GCContactsContactNumber.Name = "GCContactsContactNumber";
            this.GCContactsContactNumber.Visible = true;
            this.GCContactsContactNumber.VisibleIndex = 1;
            this.GCContactsContactNumber.Width = 156;
            // 
            // GCContactsGroupID
            // 
            this.GCContactsGroupID.AppearanceCell.Options.UseTextOptions = true;
            this.GCContactsGroupID.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.GCContactsGroupID.AppearanceHeader.Options.UseTextOptions = true;
            this.GCContactsGroupID.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.GCContactsGroupID.Caption = "������";
            this.GCContactsGroupID.ColumnEdit = this.repositoryItemGridLookUpEditGroupName;
            this.GCContactsGroupID.FieldName = "GroupID";
            this.GCContactsGroupID.Name = "GCContactsGroupID";
            this.GCContactsGroupID.Visible = true;
            this.GCContactsGroupID.VisibleIndex = 2;
            this.GCContactsGroupID.Width = 131;
            // 
            // repositoryItemGridLookUpEditGroupName
            // 
            this.repositoryItemGridLookUpEditGroupName.AutoHeight = false;
            this.repositoryItemGridLookUpEditGroupName.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemGridLookUpEditGroupName.Name = "repositoryItemGridLookUpEditGroupName";
            this.repositoryItemGridLookUpEditGroupName.NullText = "";
            this.repositoryItemGridLookUpEditGroupName.View = this.repositoryItemGridLookUpEdit1View;
            // 
            // repositoryItemGridLookUpEdit1View
            // 
            this.repositoryItemGridLookUpEdit1View.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.GCGroupName});
            this.repositoryItemGridLookUpEdit1View.FocusRectStyle = DevExpress.XtraGrid.Views.Grid.DrawFocusRectStyle.RowFocus;
            this.repositoryItemGridLookUpEdit1View.Name = "repositoryItemGridLookUpEdit1View";
            this.repositoryItemGridLookUpEdit1View.OptionsSelection.EnableAppearanceFocusedCell = false;
            this.repositoryItemGridLookUpEdit1View.OptionsView.ShowGroupPanel = false;
            // 
            // GCGroupName
            // 
            this.GCGroupName.AppearanceCell.Options.UseTextOptions = true;
            this.GCGroupName.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.GCGroupName.AppearanceHeader.Options.UseTextOptions = true;
            this.GCGroupName.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.GCGroupName.Caption = "��� ������";
            this.GCGroupName.FieldName = "GroupName";
            this.GCGroupName.Name = "GCGroupName";
            this.GCGroupName.Visible = true;
            this.GCGroupName.VisibleIndex = 0;
            // 
            // GCContactsUse
            // 
            this.GCContactsUse.AppearanceCell.Options.UseTextOptions = true;
            this.GCContactsUse.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.GCContactsUse.AppearanceHeader.Options.UseTextOptions = true;
            this.GCContactsUse.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.GCContactsUse.Caption = "�������";
            this.GCContactsUse.ColumnEdit = this.repositoryItemButtonEditSettingUse;
            this.GCContactsUse.Name = "GCContactsUse";
            this.GCContactsUse.Visible = true;
            this.GCContactsUse.VisibleIndex = 3;
            this.GCContactsUse.Width = 118;
            // 
            // GCContactSave
            // 
            this.GCContactSave.AppearanceCell.Options.UseTextOptions = true;
            this.GCContactSave.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.GCContactSave.AppearanceHeader.Options.UseTextOptions = true;
            this.GCContactSave.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.GCContactSave.Caption = "���";
            this.GCContactSave.ColumnEdit = this.repositoryItemButtonEditSave;
            this.GCContactSave.Name = "GCContactSave";
            this.GCContactSave.Visible = true;
            this.GCContactSave.VisibleIndex = 4;
            this.GCContactSave.Width = 84;
            // 
            // GCContactsDel
            // 
            this.GCContactsDel.AppearanceCell.Options.UseTextOptions = true;
            this.GCContactsDel.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.GCContactsDel.AppearanceHeader.Options.UseTextOptions = true;
            this.GCContactsDel.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.GCContactsDel.Caption = "���";
            this.GCContactsDel.ColumnEdit = this.repositoryItemButtonEditSettingDel;
            this.GCContactsDel.Name = "GCContactsDel";
            this.GCContactsDel.Visible = true;
            this.GCContactsDel.VisibleIndex = 5;
            this.GCContactsDel.Width = 85;
            // 
            // layoutViewSkinStyle
            // 
            this.layoutViewSkinStyle.CardMinSize = new System.Drawing.Size(268, 116);
            this.layoutViewSkinStyle.Columns.AddRange(new DevExpress.XtraGrid.Columns.LayoutViewColumn[] {
            this.layoutViewColumnSkinStyle,
            this.layoutViewColumnUse});
            this.layoutViewSkinStyle.GridControl = this.gridControlMain;
            this.layoutViewSkinStyle.Name = "layoutViewSkinStyle";
            this.layoutViewSkinStyle.OptionsView.ShowCardFieldBorders = true;
            this.layoutViewSkinStyle.OptionsView.ShowFilterPanelMode = DevExpress.XtraGrid.Views.Base.ShowFilterPanelMode.Never;
            this.layoutViewSkinStyle.OptionsView.ViewMode = DevExpress.XtraGrid.Views.Layout.LayoutViewMode.Carousel;
            this.layoutViewSkinStyle.TemplateCard = this.layoutViewCard1;
            // 
            // layoutViewColumnSkinStyle
            // 
            this.layoutViewColumnSkinStyle.AppearanceCell.Options.UseTextOptions = true;
            this.layoutViewColumnSkinStyle.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.layoutViewColumnSkinStyle.AppearanceHeader.Options.UseTextOptions = true;
            this.layoutViewColumnSkinStyle.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.layoutViewColumnSkinStyle.Caption = "��� �����";
            this.layoutViewColumnSkinStyle.FieldName = "StykeName";
            this.layoutViewColumnSkinStyle.LayoutViewField = this.layoutViewField_layoutViewColumnSkinStyle;
            this.layoutViewColumnSkinStyle.Name = "layoutViewColumnSkinStyle";
            this.layoutViewColumnSkinStyle.OptionsColumn.AllowEdit = false;
            this.layoutViewColumnSkinStyle.OptionsColumn.ReadOnly = true;
            // 
            // layoutViewField_layoutViewColumnSkinStyle
            // 
            this.layoutViewField_layoutViewColumnSkinStyle.EditorPreferredWidth = 172;
            this.layoutViewField_layoutViewColumnSkinStyle.Location = new System.Drawing.Point(0, 0);
            this.layoutViewField_layoutViewColumnSkinStyle.Name = "layoutViewField_layoutViewColumnSkinStyle";
            this.layoutViewField_layoutViewColumnSkinStyle.Size = new System.Drawing.Size(262, 40);
            this.layoutViewField_layoutViewColumnSkinStyle.Spacing = new DevExpress.XtraLayout.Utils.Padding(10, 10, 10, 10);
            this.layoutViewField_layoutViewColumnSkinStyle.TextLocation = DevExpress.Utils.Locations.Right;
            this.layoutViewField_layoutViewColumnSkinStyle.TextSize = new System.Drawing.Size(61, 13);
            this.layoutViewField_layoutViewColumnSkinStyle.TextToControlDistance = 5;
            // 
            // layoutViewColumnUse
            // 
            this.layoutViewColumnUse.AppearanceCell.Options.UseTextOptions = true;
            this.layoutViewColumnUse.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.layoutViewColumnUse.AppearanceHeader.Options.UseTextOptions = true;
            this.layoutViewColumnUse.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.layoutViewColumnUse.Caption = "�������";
            this.layoutViewColumnUse.ColumnEdit = this.repositoryItemButtonEditSettingUse;
            this.layoutViewColumnUse.LayoutViewField = this.layoutViewField_layoutViewColumnUse;
            this.layoutViewColumnUse.Name = "layoutViewColumnUse";
            // 
            // layoutViewField_layoutViewColumnUse
            // 
            this.layoutViewField_layoutViewColumnUse.EditorPreferredWidth = 172;
            this.layoutViewField_layoutViewColumnUse.Location = new System.Drawing.Point(0, 40);
            this.layoutViewField_layoutViewColumnUse.Name = "layoutViewField_layoutViewColumnUse";
            this.layoutViewField_layoutViewColumnUse.Size = new System.Drawing.Size(262, 40);
            this.layoutViewField_layoutViewColumnUse.Spacing = new DevExpress.XtraLayout.Utils.Padding(10, 10, 10, 10);
            this.layoutViewField_layoutViewColumnUse.TextLocation = DevExpress.Utils.Locations.Right;
            this.layoutViewField_layoutViewColumnUse.TextSize = new System.Drawing.Size(61, 13);
            this.layoutViewField_layoutViewColumnUse.TextToControlDistance = 5;
            // 
            // layoutViewCard1
            // 
            this.layoutViewCard1.CustomizationFormText = "TemplateCard";
            this.layoutViewCard1.ExpandButtonLocation = DevExpress.Utils.GroupElementLocation.AfterText;
            this.layoutViewCard1.Items.AddRange(new DevExpress.XtraLayout.BaseLayoutItem[] {
            this.layoutViewField_layoutViewColumnSkinStyle,
            this.layoutViewField_layoutViewColumnUse});
            this.layoutViewCard1.Name = "layoutViewCard1";
            this.layoutViewCard1.OptionsItemText.TextToControlDistance = 5;
            this.layoutViewCard1.Padding = new DevExpress.XtraLayout.Utils.Padding(2, 2, 2, 2);
            this.layoutViewCard1.Text = "TemplateCard";
            // 
            // gridViewSetting
            // 
            this.gridViewSetting.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.GCServiceNum,
            this.GCSettingSave,
            this.GCSettingUse,
            this.GCSettingDel});
            this.gridViewSetting.GridControl = this.gridControlMain;
            this.gridViewSetting.Name = "gridViewSetting";
            this.gridViewSetting.OptionsView.ColumnAutoWidth = false;
            // 
            // GCServiceNum
            // 
            this.GCServiceNum.AppearanceCell.Options.UseTextOptions = true;
            this.GCServiceNum.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.GCServiceNum.AppearanceHeader.Options.UseTextOptions = true;
            this.GCServiceNum.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.GCServiceNum.Caption = "��� ������ ������";
            this.GCServiceNum.FieldName = "ServiceNum";
            this.GCServiceNum.Name = "GCServiceNum";
            this.GCServiceNum.Visible = true;
            this.GCServiceNum.VisibleIndex = 0;
            this.GCServiceNum.Width = 326;
            // 
            // GCSettingSave
            // 
            this.GCSettingSave.AppearanceCell.Options.UseTextOptions = true;
            this.GCSettingSave.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.GCSettingSave.AppearanceHeader.Options.UseTextOptions = true;
            this.GCSettingSave.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.GCSettingSave.Caption = "���";
            this.GCSettingSave.ColumnEdit = this.repositoryItemButtonEditSave;
            this.GCSettingSave.Name = "GCSettingSave";
            this.GCSettingSave.Visible = true;
            this.GCSettingSave.VisibleIndex = 2;
            // 
            // GCSettingUse
            // 
            this.GCSettingUse.AppearanceCell.Options.UseTextOptions = true;
            this.GCSettingUse.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.GCSettingUse.AppearanceHeader.Options.UseTextOptions = true;
            this.GCSettingUse.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.GCSettingUse.Caption = "�������";
            this.GCSettingUse.ColumnEdit = this.repositoryItemButtonEditSettingUse;
            this.GCSettingUse.Name = "GCSettingUse";
            this.GCSettingUse.Visible = true;
            this.GCSettingUse.VisibleIndex = 1;
            this.GCSettingUse.Width = 148;
            // 
            // GCSettingDel
            // 
            this.GCSettingDel.AppearanceCell.Options.UseTextOptions = true;
            this.GCSettingDel.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.GCSettingDel.AppearanceHeader.Options.UseTextOptions = true;
            this.GCSettingDel.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.GCSettingDel.Caption = "���";
            this.GCSettingDel.ColumnEdit = this.repositoryItemButtonEditSettingDel;
            this.GCSettingDel.Name = "GCSettingDel";
            this.GCSettingDel.Visible = true;
            this.GCSettingDel.VisibleIndex = 3;
            // 
            // splitContainerControl
            // 
            this.splitContainerControl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainerControl.Location = new System.Drawing.Point(0, 0);
            this.splitContainerControl.Name = "splitContainerControl";
            this.splitContainerControl.Padding = new System.Windows.Forms.Padding(6);
            this.splitContainerControl.Panel1.Controls.Add(this.navBarControl);
            this.splitContainerControl.Panel1.Text = "Panel1";
            this.splitContainerControl.Panel2.Controls.Add(this.groupControl1);
            this.splitContainerControl.Panel2.Controls.Add(this.gridControlMain);
            this.splitContainerControl.Panel2.Text = "Panel2";
            this.splitContainerControl.Size = new System.Drawing.Size(909, 550);
            this.splitContainerControl.SplitterPosition = 165;
            this.splitContainerControl.TabIndex = 0;
            this.splitContainerControl.Text = "splitContainerControl1";
            // 
            // navBarControl
            // 
            this.navBarControl.ActiveGroup = this.msmGroup;
            this.navBarControl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.navBarControl.Groups.AddRange(new DevExpress.XtraNavBar.NavBarGroup[] {
            this.msmGroup,
            this.AdminGroup});
            this.navBarControl.Items.AddRange(new DevExpress.XtraNavBar.NavBarItem[] {
            this.navBarItemMessages,
            this.navBarItemSetting,
            this.navBarItemTemplates,
            this.navBarItemUsers,
            this.navBarItemGroups,
            this.navBarItemContacts,
            this.navBarItemStyles});
            this.navBarControl.LargeImages = this.navbarImageListLarge;
            this.navBarControl.Location = new System.Drawing.Point(0, 0);
            this.navBarControl.Name = "navBarControl";
            this.navBarControl.OptionsNavPane.ExpandedWidth = 322;
            this.navBarControl.PaintStyleKind = DevExpress.XtraNavBar.NavBarViewKind.NavigationPane;
            this.navBarControl.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.navBarControl.Size = new System.Drawing.Size(165, 538);
            this.navBarControl.SmallImages = this.navbarImageList;
            this.navBarControl.StoreDefaultPaintStyleName = true;
            this.navBarControl.TabIndex = 1;
            this.navBarControl.Text = "navBarControl1";
            // 
            // msmGroup
            // 
            this.msmGroup.Caption = "�������";
            this.msmGroup.Expanded = true;
            this.msmGroup.ItemLinks.AddRange(new DevExpress.XtraNavBar.NavBarItemLink[] {
            new DevExpress.XtraNavBar.NavBarItemLink(this.navBarItemContacts),
            new DevExpress.XtraNavBar.NavBarItemLink(this.navBarItemGroups),
            new DevExpress.XtraNavBar.NavBarItemLink(this.navBarItemMessages)});
            this.msmGroup.LargeImageIndex = 0;
            this.msmGroup.Name = "msmGroup";
            // 
            // navBarItemContacts
            // 
            this.navBarItemContacts.Caption = "�������";
            this.navBarItemContacts.Name = "navBarItemContacts";
            this.navBarItemContacts.SmallImageIndex = 5;
            this.navBarItemContacts.LinkClicked += new DevExpress.XtraNavBar.NavBarLinkEventHandler(this.navBarItemContacts_LinkClicked);
            // 
            // navBarItemGroups
            // 
            this.navBarItemGroups.Caption = "���������";
            this.navBarItemGroups.Name = "navBarItemGroups";
            this.navBarItemGroups.SmallImageIndex = 6;
            this.navBarItemGroups.LinkClicked += new DevExpress.XtraNavBar.NavBarLinkEventHandler(this.navBarItemGroups_LinkClicked);
            // 
            // navBarItemMessages
            // 
            this.navBarItemMessages.Caption = "�������";
            this.navBarItemMessages.Name = "navBarItemMessages";
            this.navBarItemMessages.SmallImageIndex = 4;
            this.navBarItemMessages.LinkClicked += new DevExpress.XtraNavBar.NavBarLinkEventHandler(this.navBarItemMessages_LinkClicked);
            // 
            // AdminGroup
            // 
            this.AdminGroup.Caption = "������";
            this.AdminGroup.ItemLinks.AddRange(new DevExpress.XtraNavBar.NavBarItemLink[] {
            new DevExpress.XtraNavBar.NavBarItemLink(this.navBarItemUsers),
            new DevExpress.XtraNavBar.NavBarItemLink(this.navBarItemTemplates),
            new DevExpress.XtraNavBar.NavBarItemLink(this.navBarItemSetting),
            new DevExpress.XtraNavBar.NavBarItemLink(this.navBarItemStyles)});
            this.AdminGroup.LargeImageIndex = 1;
            this.AdminGroup.Name = "AdminGroup";
            // 
            // navBarItemUsers
            // 
            this.navBarItemUsers.Caption = "����������";
            this.navBarItemUsers.Name = "navBarItemUsers";
            this.navBarItemUsers.SmallImageIndex = 3;
            this.navBarItemUsers.LinkClicked += new DevExpress.XtraNavBar.NavBarLinkEventHandler(this.navBarItemUsers_LinkClicked);
            // 
            // navBarItemTemplates
            // 
            this.navBarItemTemplates.Caption = "����� �����";
            this.navBarItemTemplates.Name = "navBarItemTemplates";
            this.navBarItemTemplates.SmallImageIndex = 2;
            this.navBarItemTemplates.LinkClicked += new DevExpress.XtraNavBar.NavBarLinkEventHandler(this.navBarItemTemplates_LinkClicked);
            // 
            // navBarItemSetting
            // 
            this.navBarItemSetting.Caption = "����� ����� ������";
            this.navBarItemSetting.Name = "navBarItemSetting";
            this.navBarItemSetting.SmallImageIndex = 1;
            this.navBarItemSetting.LinkClicked += new DevExpress.XtraNavBar.NavBarLinkEventHandler(this.navBarItemSetting_LinkClicked);
            // 
            // navBarItemStyles
            // 
            this.navBarItemStyles.Caption = "����� ��������";
            this.navBarItemStyles.Name = "navBarItemStyles";
            this.navBarItemStyles.SmallImageIndex = 7;
            this.navBarItemStyles.LinkClicked += new DevExpress.XtraNavBar.NavBarLinkEventHandler(this.navBarItemStyles_LinkClicked);
            // 
            // navbarImageListLarge
            // 
            this.navbarImageListLarge.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("navbarImageListLarge.ImageStream")));
            this.navbarImageListLarge.TransparentColor = System.Drawing.Color.Transparent;
            this.navbarImageListLarge.Images.SetKeyName(0, "Mail_32x32.png");
            this.navbarImageListLarge.Images.SetKeyName(1, "Organizer_32x32.png");
            this.navbarImageListLarge.Images.SetKeyName(2, "connect.png");
            this.navbarImageListLarge.Images.SetKeyName(3, "disconnect.png");
            this.navbarImageListLarge.Images.SetKeyName(4, "ports.png");
            this.navbarImageListLarge.Images.SetKeyName(5, "ServiceNo.png");
            this.navbarImageListLarge.Images.SetKeyName(6, "Send.png");
            // 
            // navbarImageList
            // 
            this.navbarImageList.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("navbarImageList.ImageStream")));
            this.navbarImageList.TransparentColor = System.Drawing.Color.Transparent;
            this.navbarImageList.Images.SetKeyName(0, "delete.png");
            this.navbarImageList.Images.SetKeyName(1, "setting.ico");
            this.navbarImageList.Images.SetKeyName(2, "Templates.ico");
            this.navbarImageList.Images.SetKeyName(3, "User.ico");
            this.navbarImageList.Images.SetKeyName(4, "Send.png");
            this.navbarImageList.Images.SetKeyName(5, "Contacts.ico");
            this.navbarImageList.Images.SetKeyName(6, "Groups.ico");
            this.navbarImageList.Images.SetKeyName(7, "styles.ico");
            // 
            // groupControl1
            // 
            this.groupControl1.AppearanceCaption.Options.UseTextOptions = true;
            this.groupControl1.AppearanceCaption.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.groupControl1.Controls.Add(this.LblMsg);
            this.groupControl1.Controls.Add(this.BtnDisconnect);
            this.groupControl1.Controls.Add(this.PnlConnection);
            this.groupControl1.Controls.Add(this.PnlSend);
            this.groupControl1.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupControl1.Location = new System.Drawing.Point(0, 0);
            this.groupControl1.Name = "groupControl1";
            this.groupControl1.Size = new System.Drawing.Size(727, 198);
            this.groupControl1.TabIndex = 1;
            this.groupControl1.Text = "�������";
            // 
            // LblMsg
            // 
            this.LblMsg.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.LblMsg.Appearance.Font = new System.Drawing.Font("Tahoma", 8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))));
            this.LblMsg.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.LblMsg.Location = new System.Drawing.Point(4, 180);
            this.LblMsg.Name = "LblMsg";
            this.LblMsg.Size = new System.Drawing.Size(51, 13);
            this.LblMsg.TabIndex = 4;
            this.LblMsg.Text = "��� ����";
            this.LblMsg.DoubleClick += new System.EventHandler(this.LblMsg_DoubleClick);
            // 
            // BtnDisconnect
            // 
            this.BtnDisconnect.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.BtnDisconnect.ImageIndex = 3;
            this.BtnDisconnect.ImageList = this.navbarImageListLarge;
            this.BtnDisconnect.Location = new System.Drawing.Point(482, 160);
            this.BtnDisconnect.Name = "BtnDisconnect";
            this.BtnDisconnect.Size = new System.Drawing.Size(157, 33);
            this.BtnDisconnect.TabIndex = 3;
            this.BtnDisconnect.Text = "��� �������";
            this.BtnDisconnect.Visible = false;
            this.BtnDisconnect.Click += new System.EventHandler(this.BtnDisconnect_Click);
            // 
            // PnlConnection
            // 
            this.PnlConnection.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.PnlConnection.Controls.Add(this.TxtServiceNum);
            this.PnlConnection.Controls.Add(this.BtnConnect);
            this.PnlConnection.Controls.Add(this.labelControl2);
            this.PnlConnection.Controls.Add(this.labelControl1);
            this.PnlConnection.Controls.Add(this.CBEPort);
            this.PnlConnection.Controls.Add(this.PBSignal);
            this.PnlConnection.Location = new System.Drawing.Point(423, 24);
            this.PnlConnection.Name = "PnlConnection";
            this.PnlConnection.Size = new System.Drawing.Size(298, 130);
            this.PnlConnection.TabIndex = 1;
            // 
            // TxtServiceNum
            // 
            this.TxtServiceNum.Location = new System.Drawing.Point(59, 64);
            this.TxtServiceNum.Name = "TxtServiceNum";
            this.TxtServiceNum.Size = new System.Drawing.Size(157, 19);
            this.TxtServiceNum.TabIndex = 4;
            // 
            // BtnConnect
            // 
            this.BtnConnect.ImageIndex = 2;
            this.BtnConnect.ImageList = this.navbarImageListLarge;
            this.BtnConnect.Location = new System.Drawing.Point(59, 89);
            this.BtnConnect.Name = "BtnConnect";
            this.BtnConnect.Size = new System.Drawing.Size(157, 33);
            this.BtnConnect.TabIndex = 3;
            this.BtnConnect.Text = "�����";
            this.BtnConnect.Click += new System.EventHandler(this.BtnConnect_Click);
            // 
            // labelControl2
            // 
            this.labelControl2.Appearance.ImageIndex = 5;
            this.labelControl2.Appearance.ImageList = this.navbarImageListLarge;
            this.labelControl2.ImageAlignToText = DevExpress.XtraEditors.ImageAlignToText.LeftCenter;
            this.labelControl2.Location = new System.Drawing.Point(222, 56);
            this.labelControl2.Name = "labelControl2";
            this.labelControl2.Size = new System.Drawing.Size(37, 36);
            this.labelControl2.TabIndex = 2;
            // 
            // labelControl1
            // 
            this.labelControl1.Appearance.ImageIndex = 4;
            this.labelControl1.Appearance.ImageList = this.navbarImageListLarge;
            this.labelControl1.ImageAlignToText = DevExpress.XtraEditors.ImageAlignToText.LeftCenter;
            this.labelControl1.Location = new System.Drawing.Point(222, 14);
            this.labelControl1.Name = "labelControl1";
            this.labelControl1.Size = new System.Drawing.Size(37, 36);
            this.labelControl1.TabIndex = 2;
            // 
            // CBEPort
            // 
            this.CBEPort.Location = new System.Drawing.Point(59, 22);
            this.CBEPort.Name = "CBEPort";
            this.CBEPort.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.CBEPort.Size = new System.Drawing.Size(157, 19);
            this.CBEPort.TabIndex = 1;
            // 
            // PBSignal
            // 
            this.PBSignal.Dock = System.Windows.Forms.DockStyle.Left;
            this.PBSignal.Location = new System.Drawing.Point(2, 2);
            this.PBSignal.Name = "PBSignal";
            this.PBSignal.Properties.Maximum = 31;
            this.PBSignal.Properties.ProgressKind = DevExpress.XtraEditors.Controls.ProgressKind.Vertical;
            this.PBSignal.Size = new System.Drawing.Size(28, 126);
            this.PBSignal.TabIndex = 5;
            // 
            // PnlSend
            // 
            this.PnlSend.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.PnlSend.Controls.Add(this.LblMsgCounter);
            this.PnlSend.Controls.Add(this.LblCharCounter);
            this.PnlSend.Controls.Add(this.btnSend);
            this.PnlSend.Controls.Add(this.BtnDelSendTo);
            this.PnlSend.Controls.Add(this.LBCSendTo);
            this.PnlSend.Controls.Add(this.TxtMsg);
            this.PnlSend.Enabled = false;
            this.PnlSend.Location = new System.Drawing.Point(9, 24);
            this.PnlSend.Name = "PnlSend";
            this.PnlSend.Size = new System.Drawing.Size(409, 155);
            this.PnlSend.TabIndex = 0;
            // 
            // LblCharCounter
            // 
            this.LblCharCounter.AutoSize = true;
            this.LblCharCounter.Location = new System.Drawing.Point(190, 136);
            this.LblCharCounter.Name = "LblCharCounter";
            this.LblCharCounter.Size = new System.Drawing.Size(13, 13);
            this.LblCharCounter.TabIndex = 5;
            this.LblCharCounter.Text = "0";
            // 
            // btnSend
            // 
            this.btnSend.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.btnSend.ImageIndex = 6;
            this.btnSend.ImageList = this.navbarImageListLarge;
            this.btnSend.Location = new System.Drawing.Point(5, 113);
            this.btnSend.Name = "btnSend";
            this.btnSend.Size = new System.Drawing.Size(179, 37);
            this.btnSend.TabIndex = 4;
            this.btnSend.Text = "�����";
            this.btnSend.Click += new System.EventHandler(this.btnSend_Click);
            // 
            // BtnDelSendTo
            // 
            this.BtnDelSendTo.ImageIndex = 0;
            this.BtnDelSendTo.ImageList = this.navbarImageList;
            this.BtnDelSendTo.Location = new System.Drawing.Point(288, 128);
            this.BtnDelSendTo.Name = "BtnDelSendTo";
            this.BtnDelSendTo.Size = new System.Drawing.Size(86, 22);
            this.BtnDelSendTo.TabIndex = 3;
            this.BtnDelSendTo.Text = "���";
            this.BtnDelSendTo.Click += new System.EventHandler(this.BtnDelSendTo_Click);
            // 
            // LBCSendTo
            // 
            this.LBCSendTo.Appearance.Options.UseTextOptions = true;
            this.LBCSendTo.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.LBCSendTo.Location = new System.Drawing.Point(255, 5);
            this.LBCSendTo.Name = "LBCSendTo";
            this.LBCSendTo.Size = new System.Drawing.Size(150, 117);
            this.LBCSendTo.TabIndex = 2;
            // 
            // TxtMsg
            // 
            this.TxtMsg.Location = new System.Drawing.Point(5, 5);
            this.TxtMsg.Name = "TxtMsg";
            this.TxtMsg.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.TxtMsg.Size = new System.Drawing.Size(245, 102);
            this.TxtMsg.TabIndex = 1;
            this.TxtMsg.EditValueChanged += new System.EventHandler(this.TxtMsg_EditValueChanged);
            // 
            // USBserialPort
            // 
            this.USBserialPort.ReadTimeout = 1000;
            this.USBserialPort.WriteTimeout = 1000;
            this.USBserialPort.DataReceived += new System.IO.Ports.SerialDataReceivedEventHandler(this.USBserialPort_DataReceived);
            // 
            // TmrSignal
            // 
            this.TmrSignal.Interval = 2000;
            this.TmrSignal.Tick += new System.EventHandler(this.TmrSignal_Tick);
            // 
            // LblMsgCounter
            // 
            this.LblMsgCounter.AutoSize = true;
            this.LblMsgCounter.Location = new System.Drawing.Point(190, 117);
            this.LblMsgCounter.Name = "LblMsgCounter";
            this.LblMsgCounter.Size = new System.Drawing.Size(13, 13);
            this.LblMsgCounter.TabIndex = 5;
            this.LblMsgCounter.Text = "0";
            // 
            // MainFrm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(909, 550);
            this.Controls.Add(this.splitContainerControl);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "MainFrm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "School Messages";
            this.Load += new System.EventHandler(this.MainFrm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.gridViewGroups)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemButtonEditSettingUse)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemButtonEditSave)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemButtonEditSettingDel)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridControlMain)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridViewMessages)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemDateEditDate.VistaTimeProperties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemDateEditDate)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridViewTemplates)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridViewUsers)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridViewContacts)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemGridLookUpEditGroupName)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemGridLookUpEdit1View)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutViewSkinStyle)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutViewField_layoutViewColumnSkinStyle)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutViewField_layoutViewColumnUse)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutViewCard1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridViewSetting)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainerControl)).EndInit();
            this.splitContainerControl.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.navBarControl)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.groupControl1)).EndInit();
            this.groupControl1.ResumeLayout(false);
            this.groupControl1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PnlConnection)).EndInit();
            this.PnlConnection.ResumeLayout(false);
            this.PnlConnection.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.TxtServiceNum.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.CBEPort.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBSignal.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PnlSend)).EndInit();
            this.PnlSend.ResumeLayout(false);
            this.PnlSend.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.LBCSendTo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtMsg.Properties)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private DevExpress.XtraEditors.SplitContainerControl splitContainerControl;
        private DevExpress.XtraGrid.GridControl gridControlMain;
        private DevExpress.XtraGrid.Views.Grid.GridView gridViewGroups;
        private DevExpress.XtraNavBar.NavBarControl navBarControl;
        private DevExpress.XtraNavBar.NavBarGroup msmGroup;
        private DevExpress.XtraNavBar.NavBarGroup AdminGroup;
        private System.Windows.Forms.ImageList navbarImageList;
        private System.Windows.Forms.ImageList navbarImageListLarge;
        private DevExpress.XtraEditors.GroupControl groupControl1;
        private DevExpress.XtraEditors.PanelControl PnlSend;
        private DevExpress.XtraEditors.MemoEdit TxtMsg;
        private DevExpress.XtraEditors.ListBoxControl LBCSendTo;
        private DevExpress.XtraEditors.PanelControl PnlConnection;
        private DevExpress.XtraEditors.LabelControl labelControl2;
        private DevExpress.XtraEditors.LabelControl labelControl1;
        private DevExpress.XtraEditors.ComboBoxEdit CBEPort;
        private DevExpress.XtraEditors.SimpleButton BtnDelSendTo;
        private DevExpress.XtraEditors.SimpleButton BtnConnect;
        private DevExpress.XtraEditors.SimpleButton BtnDisconnect;
        public DevExpress.XtraEditors.LabelControl LblMsg;
        private DevExpress.XtraGrid.Views.Grid.GridView gridViewMessages;
        private DevExpress.XtraGrid.Views.Grid.GridView gridViewContacts;
        private DevExpress.XtraGrid.Views.Grid.GridView gridViewTemplates;
        private DevExpress.XtraGrid.Views.Grid.GridView gridViewUsers;
        private DevExpress.XtraGrid.Views.Grid.GridView gridViewSetting;
        private DevExpress.XtraEditors.TextEdit TxtServiceNum;
        private DevExpress.XtraGrid.Columns.GridColumn GCServiceNum;
        private DevExpress.XtraGrid.Columns.GridColumn GCSettingUse;
        private DevExpress.XtraEditors.Repository.RepositoryItemButtonEdit repositoryItemButtonEditSettingUse;
        private DevExpress.XtraGrid.Columns.GridColumn GCSettingDel;
        private DevExpress.XtraEditors.Repository.RepositoryItemButtonEdit repositoryItemButtonEditSettingDel;
        private DevExpress.XtraEditors.SimpleButton btnSend;
        private System.IO.Ports.SerialPort USBserialPort;
        private DevExpress.XtraNavBar.NavBarItem navBarItemUsers;
        private DevExpress.XtraNavBar.NavBarItem navBarItemTemplates;
        private DevExpress.XtraNavBar.NavBarItem navBarItemSetting;
        private DevExpress.XtraNavBar.NavBarItem navBarItemMessages;
        private DevExpress.XtraGrid.Columns.GridColumn GCGroupsGroupName;
        private DevExpress.XtraGrid.Columns.GridColumn GCGroupUse;
        private DevExpress.XtraGrid.Columns.GridColumn GCGroupDel;
        private DevExpress.XtraGrid.Columns.GridColumn GCMessagesnumber;
        private DevExpress.XtraGrid.Columns.GridColumn GCMessagesmessageBody;
        private DevExpress.XtraGrid.Columns.GridColumn GCMessagesstatus;
        private DevExpress.XtraGrid.Columns.GridColumn GCMessagesSendTime;
        private DevExpress.XtraEditors.Repository.RepositoryItemDateEdit repositoryItemDateEditDate;
        private DevExpress.XtraGrid.Columns.GridColumn GCMessagesUse;
        private DevExpress.XtraGrid.Columns.GridColumn GCMessagesDel;
        private DevExpress.XtraGrid.Columns.GridColumn GCContactsContactName;
        private DevExpress.XtraGrid.Columns.GridColumn GCContactsContactNumber;
        private DevExpress.XtraGrid.Columns.GridColumn GCContactsUse;
        private DevExpress.XtraGrid.Columns.GridColumn GCContactsDel;
        private DevExpress.XtraNavBar.NavBarItem navBarItemGroups;
        private DevExpress.XtraNavBar.NavBarItem navBarItemContacts;
        private DevExpress.XtraGrid.Columns.GridColumn GCGroupsSave;
        private DevExpress.XtraEditors.Repository.RepositoryItemButtonEdit repositoryItemButtonEditSave;
        private DevExpress.XtraGrid.Columns.GridColumn GCMessageSave;
        private DevExpress.XtraGrid.Columns.GridColumn GCContactSave;
        private DevExpress.XtraGrid.Columns.GridColumn GCSettingSave;
        private DevExpress.XtraGrid.Columns.GridColumn GCTemplateTemplateBody;
        private DevExpress.XtraGrid.Columns.GridColumn GCTemplateSave;
        private DevExpress.XtraGrid.Columns.GridColumn GCTemplateUse;
        private DevExpress.XtraGrid.Columns.GridColumn GCTemplateDel;
        private DevExpress.XtraGrid.Columns.GridColumn GCUsersUserName;
        private DevExpress.XtraGrid.Columns.GridColumn GCUsersPassWord;
        private DevExpress.XtraGrid.Columns.GridColumn GCUsersSave;
        private DevExpress.XtraGrid.Columns.GridColumn GCUsersDel;
        private DevExpress.XtraGrid.Columns.GridColumn GCContactsGroupID;
        private DevExpress.XtraEditors.Repository.RepositoryItemGridLookUpEdit repositoryItemGridLookUpEditGroupName;
        private DevExpress.XtraGrid.Views.Grid.GridView repositoryItemGridLookUpEdit1View;
        private DevExpress.XtraGrid.Columns.GridColumn GCGroupName;
        private DevExpress.XtraGrid.Views.Layout.LayoutView layoutViewSkinStyle;
        private DevExpress.XtraGrid.Columns.LayoutViewColumn layoutViewColumnSkinStyle;
        
        private DevExpress.XtraNavBar.NavBarItem navBarItemStyles;
        private DevExpress.XtraGrid.Columns.LayoutViewColumn layoutViewColumnUse;
        private DevExpress.XtraGrid.Views.Layout.LayoutViewField layoutViewField_layoutViewColumnSkinStyle;
        private DevExpress.XtraGrid.Views.Layout.LayoutViewField layoutViewField_layoutViewColumnUse;
        private DevExpress.XtraGrid.Views.Layout.LayoutViewCard layoutViewCard1;
        private DevExpress.XtraEditors.ProgressBarControl PBSignal;
        private System.Windows.Forms.Timer TmrSignal;
        private System.Windows.Forms.Label LblCharCounter;
        private System.Windows.Forms.Label LblMsgCounter;

    }
}
